package sudoku;

public class Sudoku {

    public static void main(String[] args) {
        /*home page*/
        GUI screen1 = new GUI();
        screen1.setVisible(true);
    }

}
